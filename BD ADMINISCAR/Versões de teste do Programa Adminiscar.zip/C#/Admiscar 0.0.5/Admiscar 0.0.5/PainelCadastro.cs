﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar_0._0._5
{
    public partial class PainelCadastro : Form
    {
        public PainelCadastro()
        {
            InitializeComponent();
        }

        private void btCadastro_Click(object sender, EventArgs e)
        {
            Cadastro_Car a = new Cadastro_Car();
            a.Show();
        }

        private void btAcessorio_Click(object sender, EventArgs e)
        {
            Cadastro_Acessorio a = new Cadastro_Acessorio();
            a.Show();
        }

        private void btConsultaCarro_Click(object sender, EventArgs e)
        {
            ConsultaCar a = new ConsultaCar();
            a.Show();
        }

        private void btExcluirCarro_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Em Manutenção", "Tenha paciência pow ;-;");
        }
    }
}
