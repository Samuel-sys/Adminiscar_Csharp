﻿namespace Admiscar_0._0._5
{
    partial class Cadastro_Acessorio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastrar = new System.Windows.Forms.Button();
            this.gboxGps = new System.Windows.Forms.GroupBox();
            this.rdbtGpsNao = new System.Windows.Forms.RadioButton();
            this.rdbtGpsSim = new System.Windows.Forms.RadioButton();
            this.gboxVidroeletrico = new System.Windows.Forms.GroupBox();
            this.rdbtVidroEletricoSim = new System.Windows.Forms.RadioButton();
            this.rdbtVidroEletricoNao = new System.Windows.Forms.RadioButton();
            this.gboxBluetooh = new System.Windows.Forms.GroupBox();
            this.rdbtBluetoothSim = new System.Windows.Forms.RadioButton();
            this.rdbtBluetoothNao = new System.Windows.Forms.RadioButton();
            this.gboxSomBluetooth = new System.Windows.Forms.GroupBox();
            this.rdbtSomBTSim = new System.Windows.Forms.RadioButton();
            this.rdbtSomBTNao = new System.Windows.Forms.RadioButton();
            this.gboxSom = new System.Windows.Forms.GroupBox();
            this.rdbtSomSim = new System.Windows.Forms.RadioButton();
            this.rdbtSomNao = new System.Windows.Forms.RadioButton();
            this.mtxtCodCar = new System.Windows.Forms.MaskedTextBox();
            this.lblCodCar = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.cbCodCar = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gboxGps.SuspendLayout();
            this.gboxVidroeletrico.SuspendLayout();
            this.gboxBluetooh.SuspendLayout();
            this.gboxSomBluetooth.SuspendLayout();
            this.gboxSom.SuspendLayout();
            this.SuspendLayout();
            // 
            // btCadastrar
            // 
            this.btCadastrar.Location = new System.Drawing.Point(192, 337);
            this.btCadastrar.Margin = new System.Windows.Forms.Padding(4);
            this.btCadastrar.Name = "btCadastrar";
            this.btCadastrar.Size = new System.Drawing.Size(173, 38);
            this.btCadastrar.TabIndex = 30;
            this.btCadastrar.Text = "Cadastrar";
            this.btCadastrar.UseVisualStyleBackColor = true;
            this.btCadastrar.Click += new System.EventHandler(this.btCadastrar_Click);
            // 
            // gboxGps
            // 
            this.gboxGps.Controls.Add(this.rdbtGpsNao);
            this.gboxGps.Controls.Add(this.rdbtGpsSim);
            this.gboxGps.Location = new System.Drawing.Point(301, 220);
            this.gboxGps.Margin = new System.Windows.Forms.Padding(4);
            this.gboxGps.Name = "gboxGps";
            this.gboxGps.Padding = new System.Windows.Forms.Padding(4);
            this.gboxGps.Size = new System.Drawing.Size(152, 68);
            this.gboxGps.TabIndex = 29;
            this.gboxGps.TabStop = false;
            this.gboxGps.Text = "GPS";
            // 
            // rdbtGpsNao
            // 
            this.rdbtGpsNao.AutoSize = true;
            this.rdbtGpsNao.Location = new System.Drawing.Point(88, 39);
            this.rdbtGpsNao.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtGpsNao.Name = "rdbtGpsNao";
            this.rdbtGpsNao.Size = new System.Drawing.Size(55, 21);
            this.rdbtGpsNao.TabIndex = 1;
            this.rdbtGpsNao.TabStop = true;
            this.rdbtGpsNao.Text = "Não";
            this.rdbtGpsNao.UseVisualStyleBackColor = true;
            // 
            // rdbtGpsSim
            // 
            this.rdbtGpsSim.AutoSize = true;
            this.rdbtGpsSim.Location = new System.Drawing.Point(8, 39);
            this.rdbtGpsSim.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtGpsSim.Name = "rdbtGpsSim";
            this.rdbtGpsSim.Size = new System.Drawing.Size(52, 21);
            this.rdbtGpsSim.TabIndex = 0;
            this.rdbtGpsSim.TabStop = true;
            this.rdbtGpsSim.Text = "Sim";
            this.rdbtGpsSim.UseVisualStyleBackColor = true;
            // 
            // gboxVidroeletrico
            // 
            this.gboxVidroeletrico.Controls.Add(this.rdbtVidroEletricoSim);
            this.gboxVidroeletrico.Controls.Add(this.rdbtVidroEletricoNao);
            this.gboxVidroeletrico.Location = new System.Drawing.Point(105, 220);
            this.gboxVidroeletrico.Margin = new System.Windows.Forms.Padding(4);
            this.gboxVidroeletrico.Name = "gboxVidroeletrico";
            this.gboxVidroeletrico.Padding = new System.Windows.Forms.Padding(4);
            this.gboxVidroeletrico.Size = new System.Drawing.Size(159, 68);
            this.gboxVidroeletrico.TabIndex = 27;
            this.gboxVidroeletrico.TabStop = false;
            this.gboxVidroeletrico.Text = "Vidro Elétrico";
            // 
            // rdbtVidroEletricoSim
            // 
            this.rdbtVidroEletricoSim.AutoSize = true;
            this.rdbtVidroEletricoSim.Location = new System.Drawing.Point(8, 44);
            this.rdbtVidroEletricoSim.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtVidroEletricoSim.Name = "rdbtVidroEletricoSim";
            this.rdbtVidroEletricoSim.Size = new System.Drawing.Size(52, 21);
            this.rdbtVidroEletricoSim.TabIndex = 15;
            this.rdbtVidroEletricoSim.TabStop = true;
            this.rdbtVidroEletricoSim.Text = "Sim";
            this.rdbtVidroEletricoSim.UseVisualStyleBackColor = true;
            // 
            // rdbtVidroEletricoNao
            // 
            this.rdbtVidroEletricoNao.AutoSize = true;
            this.rdbtVidroEletricoNao.Location = new System.Drawing.Point(85, 44);
            this.rdbtVidroEletricoNao.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtVidroEletricoNao.Name = "rdbtVidroEletricoNao";
            this.rdbtVidroEletricoNao.Size = new System.Drawing.Size(55, 21);
            this.rdbtVidroEletricoNao.TabIndex = 14;
            this.rdbtVidroEletricoNao.TabStop = true;
            this.rdbtVidroEletricoNao.Text = "Não";
            this.rdbtVidroEletricoNao.UseVisualStyleBackColor = true;
            // 
            // gboxBluetooh
            // 
            this.gboxBluetooh.Controls.Add(this.rdbtBluetoothSim);
            this.gboxBluetooh.Controls.Add(this.rdbtBluetoothNao);
            this.gboxBluetooh.Location = new System.Drawing.Point(389, 124);
            this.gboxBluetooh.Margin = new System.Windows.Forms.Padding(4);
            this.gboxBluetooh.Name = "gboxBluetooh";
            this.gboxBluetooh.Padding = new System.Windows.Forms.Padding(4);
            this.gboxBluetooh.Size = new System.Drawing.Size(164, 68);
            this.gboxBluetooh.TabIndex = 28;
            this.gboxBluetooh.TabStop = false;
            this.gboxBluetooh.Text = "Bluetooth";
            // 
            // rdbtBluetoothSim
            // 
            this.rdbtBluetoothSim.AutoSize = true;
            this.rdbtBluetoothSim.Location = new System.Drawing.Point(8, 34);
            this.rdbtBluetoothSim.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtBluetoothSim.Name = "rdbtBluetoothSim";
            this.rdbtBluetoothSim.Size = new System.Drawing.Size(52, 21);
            this.rdbtBluetoothSim.TabIndex = 13;
            this.rdbtBluetoothSim.TabStop = true;
            this.rdbtBluetoothSim.Text = "Sim";
            this.rdbtBluetoothSim.UseVisualStyleBackColor = true;
            // 
            // rdbtBluetoothNao
            // 
            this.rdbtBluetoothNao.AutoSize = true;
            this.rdbtBluetoothNao.Location = new System.Drawing.Point(101, 34);
            this.rdbtBluetoothNao.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtBluetoothNao.Name = "rdbtBluetoothNao";
            this.rdbtBluetoothNao.Size = new System.Drawing.Size(55, 21);
            this.rdbtBluetoothNao.TabIndex = 12;
            this.rdbtBluetoothNao.TabStop = true;
            this.rdbtBluetoothNao.Text = "Não";
            this.rdbtBluetoothNao.UseVisualStyleBackColor = true;
            // 
            // gboxSomBluetooth
            // 
            this.gboxSomBluetooth.Controls.Add(this.rdbtSomBTSim);
            this.gboxSomBluetooth.Controls.Add(this.rdbtSomBTNao);
            this.gboxSomBluetooth.Location = new System.Drawing.Point(200, 124);
            this.gboxSomBluetooth.Margin = new System.Windows.Forms.Padding(4);
            this.gboxSomBluetooth.Name = "gboxSomBluetooth";
            this.gboxSomBluetooth.Padding = new System.Windows.Forms.Padding(4);
            this.gboxSomBluetooth.Size = new System.Drawing.Size(164, 68);
            this.gboxSomBluetooth.TabIndex = 26;
            this.gboxSomBluetooth.TabStop = false;
            this.gboxSomBluetooth.Text = "Som Bluetooth";
            // 
            // rdbtSomBTSim
            // 
            this.rdbtSomBTSim.AutoSize = true;
            this.rdbtSomBTSim.Location = new System.Drawing.Point(8, 34);
            this.rdbtSomBTSim.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtSomBTSim.Name = "rdbtSomBTSim";
            this.rdbtSomBTSim.Size = new System.Drawing.Size(52, 21);
            this.rdbtSomBTSim.TabIndex = 9;
            this.rdbtSomBTSim.TabStop = true;
            this.rdbtSomBTSim.Text = "Sim";
            this.rdbtSomBTSim.UseVisualStyleBackColor = true;
            // 
            // rdbtSomBTNao
            // 
            this.rdbtSomBTNao.AutoSize = true;
            this.rdbtSomBTNao.Location = new System.Drawing.Point(96, 34);
            this.rdbtSomBTNao.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtSomBTNao.Name = "rdbtSomBTNao";
            this.rdbtSomBTNao.Size = new System.Drawing.Size(55, 21);
            this.rdbtSomBTNao.TabIndex = 16;
            this.rdbtSomBTNao.TabStop = true;
            this.rdbtSomBTNao.Text = "Não";
            this.rdbtSomBTNao.UseVisualStyleBackColor = true;
            // 
            // gboxSom
            // 
            this.gboxSom.Controls.Add(this.rdbtSomSim);
            this.gboxSom.Controls.Add(this.rdbtSomNao);
            this.gboxSom.Location = new System.Drawing.Point(25, 124);
            this.gboxSom.Margin = new System.Windows.Forms.Padding(4);
            this.gboxSom.Name = "gboxSom";
            this.gboxSom.Padding = new System.Windows.Forms.Padding(4);
            this.gboxSom.Size = new System.Drawing.Size(159, 68);
            this.gboxSom.TabIndex = 25;
            this.gboxSom.TabStop = false;
            this.gboxSom.Text = "Som";
            // 
            // rdbtSomSim
            // 
            this.rdbtSomSim.AutoSize = true;
            this.rdbtSomSim.Location = new System.Drawing.Point(8, 34);
            this.rdbtSomSim.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtSomSim.Name = "rdbtSomSim";
            this.rdbtSomSim.Size = new System.Drawing.Size(52, 21);
            this.rdbtSomSim.TabIndex = 11;
            this.rdbtSomSim.TabStop = true;
            this.rdbtSomSim.Text = "Sim";
            this.rdbtSomSim.UseVisualStyleBackColor = true;
            // 
            // rdbtSomNao
            // 
            this.rdbtSomNao.AutoSize = true;
            this.rdbtSomNao.Location = new System.Drawing.Point(85, 34);
            this.rdbtSomNao.Margin = new System.Windows.Forms.Padding(4);
            this.rdbtSomNao.Name = "rdbtSomNao";
            this.rdbtSomNao.Size = new System.Drawing.Size(55, 21);
            this.rdbtSomNao.TabIndex = 10;
            this.rdbtSomNao.TabStop = true;
            this.rdbtSomNao.Text = "Não";
            this.rdbtSomNao.UseVisualStyleBackColor = true;
            // 
            // mtxtCodCar
            // 
            this.mtxtCodCar.Location = new System.Drawing.Point(178, 46);
            this.mtxtCodCar.Margin = new System.Windows.Forms.Padding(4);
            this.mtxtCodCar.Name = "mtxtCodCar";
            this.mtxtCodCar.Size = new System.Drawing.Size(285, 22);
            this.mtxtCodCar.TabIndex = 24;
            // 
            // lblCodCar
            // 
            this.lblCodCar.AutoSize = true;
            this.lblCodCar.Location = new System.Drawing.Point(70, 46);
            this.lblCodCar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCodCar.Name = "lblCodCar";
            this.lblCodCar.Size = new System.Drawing.Size(95, 17);
            this.lblCodCar.TabIndex = 23;
            this.lblCodCar.Text = "Código Carro:";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(227, 12);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(138, 17);
            this.lblTitulo.TabIndex = 22;
            this.lblTitulo.Text = "Cadastro Acessorios";
            // 
            // cbCodCar
            // 
            this.cbCodCar.FormattingEnabled = true;
            this.cbCodCar.Location = new System.Drawing.Point(178, 76);
            this.cbCodCar.Name = "cbCodCar";
            this.cbCodCar.Size = new System.Drawing.Size(285, 24);
            this.cbCodCar.TabIndex = 31;
            this.cbCodCar.SelectedIndexChanged += new System.EventHandler(this.cbCodCar_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 79);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 17);
            this.label1.TabIndex = 32;
            this.label1.Text = "Carros cadastrados: ";
            // 
            // Cadastro_Acessorio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 410);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbCodCar);
            this.Controls.Add(this.btCadastrar);
            this.Controls.Add(this.gboxGps);
            this.Controls.Add(this.gboxVidroeletrico);
            this.Controls.Add(this.gboxBluetooh);
            this.Controls.Add(this.gboxSomBluetooth);
            this.Controls.Add(this.gboxSom);
            this.Controls.Add(this.mtxtCodCar);
            this.Controls.Add(this.lblCodCar);
            this.Controls.Add(this.lblTitulo);
            this.Name = "Cadastro_Acessorio";
            this.Text = "Cadastro Acessorio";
            this.Load += new System.EventHandler(this.Cadastro_Acessorio_Load);
            this.gboxGps.ResumeLayout(false);
            this.gboxGps.PerformLayout();
            this.gboxVidroeletrico.ResumeLayout(false);
            this.gboxVidroeletrico.PerformLayout();
            this.gboxBluetooh.ResumeLayout(false);
            this.gboxBluetooh.PerformLayout();
            this.gboxSomBluetooth.ResumeLayout(false);
            this.gboxSomBluetooth.PerformLayout();
            this.gboxSom.ResumeLayout(false);
            this.gboxSom.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btCadastrar;
        private System.Windows.Forms.GroupBox gboxGps;
        private System.Windows.Forms.RadioButton rdbtGpsNao;
        private System.Windows.Forms.RadioButton rdbtGpsSim;
        private System.Windows.Forms.GroupBox gboxVidroeletrico;
        private System.Windows.Forms.RadioButton rdbtVidroEletricoSim;
        private System.Windows.Forms.RadioButton rdbtVidroEletricoNao;
        private System.Windows.Forms.GroupBox gboxBluetooh;
        private System.Windows.Forms.RadioButton rdbtBluetoothSim;
        private System.Windows.Forms.RadioButton rdbtBluetoothNao;
        private System.Windows.Forms.GroupBox gboxSomBluetooth;
        private System.Windows.Forms.RadioButton rdbtSomBTSim;
        private System.Windows.Forms.RadioButton rdbtSomBTNao;
        private System.Windows.Forms.GroupBox gboxSom;
        private System.Windows.Forms.RadioButton rdbtSomSim;
        private System.Windows.Forms.RadioButton rdbtSomNao;
        private System.Windows.Forms.MaskedTextBox mtxtCodCar;
        private System.Windows.Forms.Label lblCodCar;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.ComboBox cbCodCar;
        private System.Windows.Forms.Label label1;
    }
}