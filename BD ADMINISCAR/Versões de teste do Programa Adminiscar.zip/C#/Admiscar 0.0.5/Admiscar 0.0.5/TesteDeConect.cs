﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Admiscar_0._0._5
{
    class TesteDeConect
    {
        public string test()
        {
            string resposta = "";
                //chama a class responsavel por dar o endereço (usuario e senha) do banco de dados
                BancoDeDados b = new BancoDeDados();

                //CONECTANDO AO BANCO DE DADOS
                SqlConnection con = new SqlConnection(b.BD());

                //Ponte para incerir os comando de controle entre C# e o banco de dados SQL Server
                SqlCommand comando = new SqlCommand();

                //INICIALIZAR A CONEXÃO COM O BANCO PARA TESTAR E SABER SE O ENDEREÇO E VALIDO
                comando.Connection = con;
            try
            {

                //abrindo o banco de dados para testar a conecção
                con.Open();
                resposta = "Conexão com sucesso";
            }
            catch (SqlException erro)
            {

                resposta = "Erro de conecxão \n\n" + erro.Message;
            }
            finally
            {
                frmCadastraBD a = new frmCadastraBD();
                a.Close();

                con.Close();
            }

            return resposta;
        }
    }
}
