﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar_0._0._5
{
    public partial class frmCadastraBD : Form
    {
        public frmCadastraBD()
        {
            InitializeComponent();
        }

        private void CadastraBD_Load(object sender, EventArgs e)
        {
            //se inicia com o rdbNão ativado
            rdbNao.Checked = true;
        }

        private void rdbNao_CheckedChanged(object sender, EventArgs e)
        {
            //tem a função de mostrar ou não a area de preenchimento do Usuario e Senha do banco de dados
            Esconde(rdbNao.Checked);
        }

        public void Esconde(Boolean a)
        {
            //se o rdbNão estiver selecionado a area de preenchimento do usuario e senha aparecem se não ficam invisives ao usuario
            txtUsuario.Visible = a ? true : false;
            lblUsuario.Visible = a ? true : false;
            txtSenha.Visible = a ? true : false;
            lblSenha.Visible = a ? true : false;
        }

        private void btCadastarBD_Click(object sender, EventArgs e)
        {
            //pegando os valores e colocando em variaves para te um melhor controle e conhecimento semantico
            string instancia = txtInstancia.Text; //responsavel por informa a instancia do Banco de dados
            string database = txtDataBase.Text; //responsavel por informar o nome da DataBase
            string usuario = rdbSim.Checked == false ? txtUsuario.Text : null; //responsavel por informar o user do banco de dados (se o modo Integrated Security for ativado o valor e null)
            string senha = rdbSim.Checked == false ? txtSenha.Text : null; //responsavel por informar a password do banco de dados (se o modo Integrated Security for ativado o valor e null)

            if (instancia == "" || database == "" || usuario == "" || senha == "") //lembre que null não e igual a ""
                MessageBox.Show("Preencha todos os campos", "ATENÇÃO");//informa que ainda tem campos a serem cadastrados
            else
            {
                BancoDeDados a = new BancoDeDados();
                /*Se o cliente não der nem um valor para senha ou usuario o programa entende como sendo um "Integrated Security"*/
                a.cadastraBD(instancia, database, usuario, senha);

                //faz um teste na conexão 
                TesteDeConect test = new TesteDeConect();


                //PONTE PARA SABER O BUTÃO PRECIONADO PELO CLIENTE NO MessageBox
                DialogResult r;

                do
                {
                    //faz o teste da conecção e registra a resposta do resultado na variavel resposta
                    string resposta = test.test();

                    //se for conectado informa o usuario
                    if (resposta == "Conexão com sucesso")
                    {
                        r = MessageBox.Show(resposta, "ATENÇÃO");

                        //fecha a tela depois do cadastro de Banco de Dados
                        Close();
                    }

                    //se não for conectado da a opção de repetir o teste com os mesmo dados informados
                    else
                    {
                        r = MessageBox.Show(resposta, "ATENÇÃO", MessageBoxButtons.RetryCancel);
                    }
                } while (r == DialogResult.Retry);//esse loop continua enquanto o cliente precionar o botão de repetir

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //faz o ficheiro retornar a ter o endereço padrão
            BancoDeDados a = new BancoDeDados();
            a.bancoPadrão();

            //faz um teste na conexão 
            TesteDeConect test = new TesteDeConect();

            //PONTE PARA SABER O BUTÃO PRECIONADO PELO CLIENTE NO MessageBox
            DialogResult r;

            do
            {
                //faz o teste da conecção e registra a resposta do resultado na variavel resposta
                string resposta = test.test();

                //se for conectado informa o usuario
                if (resposta == "Conexão com sucesso")
                {
                    r = MessageBox.Show("Banco de dados padrão cadastrado\n\n" + resposta, "ATENÇÃO");

                    //fecha a tela depois do cadastro de Banco de Dados
                    Close();
                }

                //se não for conectado da a opção de repetir o teste com os mesmo dados informados
                else
                {
                    r = MessageBox.Show("Banco de dados padrão cadastrado\n\n" + resposta, "ATENÇÃO", MessageBoxButtons.RetryCancel);
                }

            } while (r == DialogResult.Retry);//esse loop continua enquanto o cliente precionar o botão de repetir
        }
    }
}
