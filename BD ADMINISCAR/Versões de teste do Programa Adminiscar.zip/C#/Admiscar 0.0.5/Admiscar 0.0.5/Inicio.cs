﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar_0._0._5
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void btCadastroBD_Click(object sender, EventArgs e)
        {
            frmCadastraBD cBD = new frmCadastraBD();
            cBD.Show();
        }

        private void CadastroCarAcss_Click(object sender, EventArgs e)
        {
            //testa a conexão com o banco de dados
            TesteDeConect conect = new TesteDeConect();

            if(conect.test() == "Conexão com sucesso") {
            PainelCadastro a = new PainelCadastro();
            a.Show();
            }
            else
            {
                MessageBox.Show("Erro de conexão com o banco de dados vá a area de cadastro de banco e cadastre outro endereço", "ATENÇÃO");
            }
        }
    }
}
