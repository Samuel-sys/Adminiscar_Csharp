﻿namespace Admiscar_0._0._5
{
    partial class ConsultaCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxConsulta = new System.Windows.Forms.ListBox();
            this.lblCod = new System.Windows.Forms.Label();
            this.lblNomeCar = new System.Windows.Forms.Label();
            this.lblPlaca = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.btAtualizar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxConsulta
            // 
            this.lbxConsulta.FormattingEnabled = true;
            this.lbxConsulta.ItemHeight = 16;
            this.lbxConsulta.Location = new System.Drawing.Point(24, 60);
            this.lbxConsulta.Name = "lbxConsulta";
            this.lbxConsulta.Size = new System.Drawing.Size(525, 404);
            this.lbxConsulta.TabIndex = 0;
            // 
            // lblCod
            // 
            this.lblCod.AutoSize = true;
            this.lblCod.Location = new System.Drawing.Point(21, 39);
            this.lblCod.Name = "lblCod";
            this.lblCod.Size = new System.Drawing.Size(33, 17);
            this.lblCod.TabIndex = 1;
            this.lblCod.Text = "Cod";
            // 
            // lblNomeCar
            // 
            this.lblNomeCar.AutoSize = true;
            this.lblNomeCar.Location = new System.Drawing.Point(148, 39);
            this.lblNomeCar.Name = "lblNomeCar";
            this.lblNomeCar.Size = new System.Drawing.Size(102, 17);
            this.lblNomeCar.TabIndex = 2;
            this.lblNomeCar.Text = "Nome do carro";
            // 
            // lblPlaca
            // 
            this.lblPlaca.AutoSize = true;
            this.lblPlaca.Location = new System.Drawing.Point(281, 39);
            this.lblPlaca.Name = "lblPlaca";
            this.lblPlaca.Size = new System.Drawing.Size(43, 17);
            this.lblPlaca.TabIndex = 3;
            this.lblPlaca.Text = "Placa";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Location = new System.Drawing.Point(404, 39);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(52, 17);
            this.lblEstado.TabIndex = 4;
            this.lblEstado.Text = "Estado";
            // 
            // btAtualizar
            // 
            this.btAtualizar.Location = new System.Drawing.Point(175, 470);
            this.btAtualizar.Name = "btAtualizar";
            this.btAtualizar.Size = new System.Drawing.Size(207, 54);
            this.btAtualizar.TabIndex = 5;
            this.btAtualizar.Text = "atualizar";
            this.btAtualizar.UseVisualStyleBackColor = true;
            this.btAtualizar.Click += new System.EventHandler(this.btAtualizar_Click);
            // 
            // ConsultaCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 527);
            this.Controls.Add(this.btAtualizar);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblPlaca);
            this.Controls.Add(this.lblNomeCar);
            this.Controls.Add(this.lblCod);
            this.Controls.Add(this.lbxConsulta);
            this.Name = "ConsultaCar";
            this.Text = "ConsultaCar";
            this.Load += new System.EventHandler(this.ConsultaCar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbxConsulta;
        private System.Windows.Forms.Label lblCod;
        private System.Windows.Forms.Label lblNomeCar;
        private System.Windows.Forms.Label lblPlaca;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Button btAtualizar;
    }
}