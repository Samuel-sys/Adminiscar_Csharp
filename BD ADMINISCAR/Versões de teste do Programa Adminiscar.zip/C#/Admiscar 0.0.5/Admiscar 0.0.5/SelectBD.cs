﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Admiscar_0._0._5
{
    class SelectBD
    {
        public string selectBD(string campo, string tabela, string[] dados, string espasamento)
        {
            //variavel responsavel por entregar os dados ao cliente 
            string texto = "";//os dados irão ser enviados colados separados por um ";" tera q usar um comando Split para separar as informações

            //Classe responsavel por pegar o endereço do banco
            BancoDeDados bd = new BancoDeDados();

            //ponte de conecxão
            SqlConnection conect = new SqlConnection(bd.BD());

            //comando para puxar os dados da tabela CARRO
            SqlCommand comando = new SqlCommand("SELECT " + campo + " FROM " + tabela, conect);

            //abrindo o banco
            conect.Open();

            //execultando a leitura do banco
            SqlDataReader dr = comando.ExecuteReader();

            //o loop so ira para quando o programa ler todas as linha da tabela indicada pelo cliente
            while (dr.Read())
            {
                for (int i = 0; i < dados.Length; i++)
                {
                    //caso não seja o ultimo campo
                    if (i != dados.Length - 1)
                        texto += dr[dados[i]].ToString() + espasamento;

                    //caso seja o ultimo campo
                    else
                        texto += dr[dados[i]].ToString() + ";";//o final tem que ser um ";" para poder ser separado pelo cliente no processo de tratamento
                }
            }

            //fechando o banco
            conect.Close();

            //entrega os dados para o cliente 
            return texto;
        }
    }
}