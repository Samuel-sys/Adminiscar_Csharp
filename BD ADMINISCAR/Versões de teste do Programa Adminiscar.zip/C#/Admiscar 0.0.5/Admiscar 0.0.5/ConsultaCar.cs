﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Admiscar_0._0._5
{
    public partial class ConsultaCar : Form
    {
        public ConsultaCar()
        {
            InitializeComponent();
        }

        private void ConsultaCar_Load(object sender, EventArgs e)
        {
            //gera a lista com os dados dos carros cadastrados
            Consulta();
        }
        public void Consulta()
        {
            //OS DADOS QUE SÃO PRECISOS
            string[] dados = new string[] { "COD_CAR", "NOME_CAR", "PLACA", "ESTADO" };

            //NOME DA TABELA
            string tabela = "CARRO";

            //CAMPOS QUE PRECISAM SER PEDIDOS PARA A TABELA
            string campo = "COD_CAR, NOME_CAR, PLACA, ESTADO";

            //INSTANCIANDO A CLASSE QUE PEGA OS DADOS NO BANCO
            SelectBD sbd = new SelectBD();

            //RECEBE OS DADOS DA METODO DA CLASSE SelctBD
            string texto = sbd.selectBD(campo, tabela, dados, "\t\t"); //espasamento e o espaso entre um dado e o outro de forma fisica

            //TRATANDO OS DADOS ENTREGUES
            string[] informacoes = texto.Split(';');//SERA SEPARADO EM VETOR TODA VEZ QUE UM ';' APARECER

            //LOOP PARA ADICIONAR OS DADOS TRATADOS NO VETOR "informacao"
            for (int i = 0; i < informacoes.Length; i++)
                lbxConsulta.Items.Add(informacoes[i]);
        }

        private void btAtualizar_Click(object sender, EventArgs e)
        {
            //limpa a lista
            lbxConsulta.Items.Clear();
            //gera a lista novamente assim atualizando os itens
            Consulta();
        }
    }
}