﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Admiscar_0._0._5
{
    class InsertBD
    {
        //chama a class responsavel por dar o endereço (usuario e senha) do banco de dados
        static BancoDeDados b = new BancoDeDados();

        //CONECTANDO AO BANCO DE DADOS
        static SqlConnection con = new SqlConnection(b.BD());

        //Ponte para incerir os comando de controle entre C# e o banco de dados SQL Server
        static SqlCommand comando = new SqlCommand();

        public string insertBD(string tabela, string campos, string dados)
        {
            //INICIALIZAR A CONEXÃO COM O BANCO
            comando.Connection = con;

            string resposta;

            try
            {

                //abrindo o banco de dados 
                con.Open();

                //comandos do SQL, inserindo os dados na tabela dos campos escolhidos
                comando.CommandText = "INSERT INTO " + tabela + " (" + campos + ") VALUES ('" + dados + "')";
                comando.ExecuteNonQuery();

                resposta = "Cadastrado com sucesso";
            }
            catch (SqlException erro)
            {
                resposta = "Erro de cadastro \n\n" + erro.Message;
            }
            finally
            {
                //fechando o banco de dados
                con.Close();
            }
            return resposta;
        }
    }
}
