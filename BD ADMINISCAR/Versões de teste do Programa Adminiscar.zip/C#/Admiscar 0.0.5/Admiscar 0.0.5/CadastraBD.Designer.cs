﻿namespace Admiscar_0._0._5
{
    partial class frmCadastraBD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bgUser = new System.Windows.Forms.GroupBox();
            this.rdbNao = new System.Windows.Forms.RadioButton();
            this.rdbSim = new System.Windows.Forms.RadioButton();
            this.lblSenha = new System.Windows.Forms.Label();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.lblDataBase = new System.Windows.Forms.Label();
            this.txtDataBase = new System.Windows.Forms.TextBox();
            this.lblInstancia = new System.Windows.Forms.Label();
            this.txtInstancia = new System.Windows.Forms.TextBox();
            this.btCadastarBD = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.bgUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // bgUser
            // 
            this.bgUser.Controls.Add(this.rdbNao);
            this.bgUser.Controls.Add(this.rdbSim);
            this.bgUser.Location = new System.Drawing.Point(14, 68);
            this.bgUser.Name = "bgUser";
            this.bgUser.Size = new System.Drawing.Size(290, 57);
            this.bgUser.TabIndex = 18;
            this.bgUser.TabStop = false;
            this.bgUser.Text = "Integrated Security";
            // 
            // rdbNao
            // 
            this.rdbNao.AutoSize = true;
            this.rdbNao.Location = new System.Drawing.Point(92, 22);
            this.rdbNao.Name = "rdbNao";
            this.rdbNao.Size = new System.Drawing.Size(59, 21);
            this.rdbNao.TabIndex = 1;
            this.rdbNao.TabStop = true;
            this.rdbNao.Text = "NÃO";
            this.rdbNao.UseVisualStyleBackColor = true;
            this.rdbNao.CheckedChanged += new System.EventHandler(this.rdbNao_CheckedChanged);
            // 
            // rdbSim
            // 
            this.rdbSim.AutoSize = true;
            this.rdbSim.Location = new System.Drawing.Point(21, 22);
            this.rdbSim.Name = "rdbSim";
            this.rdbSim.Size = new System.Drawing.Size(52, 21);
            this.rdbSim.TabIndex = 0;
            this.rdbSim.TabStop = true;
            this.rdbSim.Text = "SIM";
            this.rdbSim.UseVisualStyleBackColor = true;
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Location = new System.Drawing.Point(32, 162);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(49, 17);
            this.lblSenha.TabIndex = 17;
            this.lblSenha.Text = "Senha";
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(87, 159);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(217, 22);
            this.txtSenha.TabIndex = 16;
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Location = new System.Drawing.Point(24, 134);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(57, 17);
            this.lblUsuario.TabIndex = 15;
            this.lblUsuario.Text = "Usuario";
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(87, 131);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(217, 22);
            this.txtUsuario.TabIndex = 14;
            // 
            // lblDataBase
            // 
            this.lblDataBase.AutoSize = true;
            this.lblDataBase.Location = new System.Drawing.Point(11, 43);
            this.lblDataBase.Name = "lblDataBase";
            this.lblDataBase.Size = new System.Drawing.Size(70, 17);
            this.lblDataBase.TabIndex = 13;
            this.lblDataBase.Text = "DataBase";
            // 
            // txtDataBase
            // 
            this.txtDataBase.Location = new System.Drawing.Point(87, 40);
            this.txtDataBase.Name = "txtDataBase";
            this.txtDataBase.Size = new System.Drawing.Size(217, 22);
            this.txtDataBase.TabIndex = 12;
            // 
            // lblInstancia
            // 
            this.lblInstancia.AutoSize = true;
            this.lblInstancia.Location = new System.Drawing.Point(17, 15);
            this.lblInstancia.Name = "lblInstancia";
            this.lblInstancia.Size = new System.Drawing.Size(64, 17);
            this.lblInstancia.TabIndex = 11;
            this.lblInstancia.Text = "Instancia";
            // 
            // txtInstancia
            // 
            this.txtInstancia.Location = new System.Drawing.Point(87, 12);
            this.txtInstancia.Name = "txtInstancia";
            this.txtInstancia.Size = new System.Drawing.Size(217, 22);
            this.txtInstancia.TabIndex = 10;
            // 
            // btCadastarBD
            // 
            this.btCadastarBD.Location = new System.Drawing.Point(35, 207);
            this.btCadastarBD.Name = "btCadastarBD";
            this.btCadastarBD.Size = new System.Drawing.Size(255, 86);
            this.btCadastarBD.TabIndex = 19;
            this.btCadastarBD.Text = "Cadastar";
            this.btCadastarBD.UseVisualStyleBackColor = true;
            this.btCadastarBD.Click += new System.EventHandler(this.btCadastarBD_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(123, 299);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 32);
            this.button1.TabIndex = 20;
            this.button1.Text = "(padrão)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmCadastraBD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 343);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bgUser);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.lblDataBase);
            this.Controls.Add(this.txtDataBase);
            this.Controls.Add(this.lblInstancia);
            this.Controls.Add(this.txtInstancia);
            this.Controls.Add(this.btCadastarBD);
            this.Name = "frmCadastraBD";
            this.ShowInTaskbar = false;
            this.Text = "CadastraBD";
            this.Load += new System.EventHandler(this.CadastraBD_Load);
            this.bgUser.ResumeLayout(false);
            this.bgUser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox bgUser;
        private System.Windows.Forms.RadioButton rdbNao;
        private System.Windows.Forms.RadioButton rdbSim;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.Label lblDataBase;
        private System.Windows.Forms.TextBox txtDataBase;
        private System.Windows.Forms.Label lblInstancia;
        private System.Windows.Forms.TextBox txtInstancia;
        private System.Windows.Forms.Button btCadastarBD;
        private System.Windows.Forms.Button button1;
    }
}