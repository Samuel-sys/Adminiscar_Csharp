﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar_0._0._5
{
    public partial class Cadastro_Car : Form
    {
        public Cadastro_Car()
        {
            InitializeComponent();
        }

        private void Cadastro_Car_Load(object sender, EventArgs e)
        {
            //inpede que o cliente escreva um texto na area dos ComboBox
            cbModelo.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCombustivel.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCategoria.DropDownStyle = ComboBoxStyle.DropDownList;
            cbNomeCar.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btCadastro_Click(object sender, EventArgs e)
        {

            if (txtIPVA.Text == "" || mtxtCor.Text == "" ||
                cbNomeCar.Text == "" || mtxtPlaca.Text == "" ||
                mtxtRenavam.Text == "" || cbCategoria.Text == "" ||
                cbCombustivel.Text == "" || cbModelo.Text == "")
            {
                MessageBox.Show("Preencha todos os campos!!");
            }
            else
            {

                //nome das colunas a serem cadastradas (#BD1.1)
                string campos = "QUILOMETRAGEM,AVARIA, ESTADO,RENAVAM, NOME_CAR, PLACA, MODELO, TIPO_COMBUSTIVEL, COR, CATEGORIA_CAR, COMPROVANTE_IPVA";

                //nome da tabela
                string tabela = "CARRO";

                //dados a serem gravados (#BD1.2)
                string dados = "0" + "','" + "Sem avaria" + "','" + "PÁTIO" + "','" + mtxtRenavam.Text + "','" + cbNomeCar.Text + "','" + mtxtPlaca.Text + "','" + cbModelo.Text + "','" + cbCombustivel.Text + "','" + mtxtCor.Text + "','" + cbCategoria.Text + "','" + txtIPVA.Text;

                //instanciando o objeto que sera responsavel por cuidar da parte de banco de dados
                InsertBD ibd = new InsertBD();

                //instanciando o metodo que ira registrar os dados no Banco de Dados
                ibd.insertBD(tabela, campos, dados);

                //da uma notificação dizendo que o carro foi cadastrado
                MessageBox.Show("Cadastrado");
            }

        }
    }
}
