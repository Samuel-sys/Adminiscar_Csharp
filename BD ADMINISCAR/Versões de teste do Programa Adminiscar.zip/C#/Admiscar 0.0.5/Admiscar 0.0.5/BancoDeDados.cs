﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Admiscar_0._0._5
{
    class BancoDeDados
    {

        //criando a pasta onde se cria gravara um arquivo txt com o endereço do banco de dados

        //pote de leitura e escrita
        static StreamReader sr;
        static StreamWriter sw;

        private void PastaDataBase()
        {
            DirectoryInfo di = new DirectoryInfo(@"Data");
            di.CreateSubdirectory(@"DataBase");
        }

        public void bancoPadrão()
        {
            using (sw = File.CreateText(@"Data\Database\bd.txt"))
            {
                //sistema da maquina do editor desse programa (***ENDEREÇO PADRÃO!***)
                sw.Write(@"Data Source = DESKTOP-N6E750J\SQLEXPRESS; Initial Catalog = ADMINISCAR; Integrated Security = True");
            }
        }

        public string BD()//(#BD)
        {
            PastaDataBase();

            //variavel que atribuindo endereço do banco de dados
            string local = "";

            while (local == "")
            {
                if (!File.Exists(@"Data\Database\bd.txt"))
                {
                    bancoPadrão();
                }
                else
                {
                    using (sr = File.OpenText(@"Data\Database\bd.txt"))
                    {
                        //caso já tenha cadastro no arquivo txt ele ira ler o endereço
                        local = sr.ReadLine();
                    }
                }
            }

            //retorna o endereço do banco de dados
            return local;
        }

        public void cadastraBD(string instancia, string DataBase, string usuario, string senha)
        {
            //caso a pasta não exista ela sera criada
            PastaDataBase();

            //caso o arquivo não exista sera criado um com um endereço padrão
            BD();

            //endereço do banco e da DataBase
            string banco = @"Data Source = " + instancia + "; Initial Catalog = " + DataBase;
            
            //Caso o não se de senha ou usuarioa vai se entender que e um caso de Integrated Securyt caso o contrario sera cadastrado
            banco += usuario == null && senha == null ? @"; Integrated Security = True" : " USER ID = " + usuario + " PASSWORD = " + senha;

            //Caso não passe o usuario e senha
            //Data Source = "INSTANCIA"; Initial Catalog = "DATABASE"; Integrated Security = True
            
            //Caso passe o usuario e senha
            //Data Source = "INSTANCIA"; Initial Catalog = "DATABASE"; USER ID = "usuario" PASSWORD = "senha"

            using (sw = File.CreateText(@"Data\Database\bd.txt"))
            {
                //escrevendo as informações do banco de dados no ficheiro
                sw.Write(banco);
            }
        }
    }
}
