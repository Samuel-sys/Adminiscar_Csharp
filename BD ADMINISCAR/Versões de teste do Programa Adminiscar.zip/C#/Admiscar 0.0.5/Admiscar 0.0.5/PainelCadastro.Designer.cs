﻿namespace Admiscar_0._0._5
{
    partial class PainelCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btAcessorio = new System.Windows.Forms.Button();
            this.btConsultaCarro = new System.Windows.Forms.Button();
            this.btCadastro = new System.Windows.Forms.Button();
            this.btExcluirCarro = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btAcessorio
            // 
            this.btAcessorio.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btAcessorio.Location = new System.Drawing.Point(3, 218);
            this.btAcessorio.Name = "btAcessorio";
            this.btAcessorio.Size = new System.Drawing.Size(256, 210);
            this.btAcessorio.TabIndex = 5;
            this.btAcessorio.Text = "Cadastrar de Acessorios de Carro";
            this.btAcessorio.UseVisualStyleBackColor = true;
            this.btAcessorio.Click += new System.EventHandler(this.btAcessorio_Click);
            // 
            // btConsultaCarro
            // 
            this.btConsultaCarro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btConsultaCarro.Location = new System.Drawing.Point(265, 3);
            this.btConsultaCarro.Name = "btConsultaCarro";
            this.btConsultaCarro.Size = new System.Drawing.Size(256, 209);
            this.btConsultaCarro.TabIndex = 4;
            this.btConsultaCarro.Text = "Cousultar carro";
            this.btConsultaCarro.UseVisualStyleBackColor = true;
            this.btConsultaCarro.Click += new System.EventHandler(this.btConsultaCarro_Click);
            // 
            // btCadastro
            // 
            this.btCadastro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btCadastro.Location = new System.Drawing.Point(3, 3);
            this.btCadastro.Name = "btCadastro";
            this.btCadastro.Size = new System.Drawing.Size(256, 209);
            this.btCadastro.TabIndex = 3;
            this.btCadastro.Text = "Cadastrar carro";
            this.btCadastro.UseCompatibleTextRendering = true;
            this.btCadastro.UseVisualStyleBackColor = true;
            this.btCadastro.Click += new System.EventHandler(this.btCadastro_Click);
            // 
            // btExcluirCarro
            // 
            this.btExcluirCarro.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btExcluirCarro.Location = new System.Drawing.Point(265, 218);
            this.btExcluirCarro.Name = "btExcluirCarro";
            this.btExcluirCarro.Size = new System.Drawing.Size(256, 210);
            this.btExcluirCarro.TabIndex = 6;
            this.btExcluirCarro.Text = "Excluir Carro";
            this.btExcluirCarro.UseVisualStyleBackColor = true;
            this.btExcluirCarro.Click += new System.EventHandler(this.btExcluirCarro_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btCadastro, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btAcessorio, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btExcluirCarro, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btConsultaCarro, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(2, 1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(524, 431);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // PainelCadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 431);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "PainelCadastro";
            this.Text = "Painel Cadastro";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btAcessorio;
        private System.Windows.Forms.Button btConsultaCarro;
        private System.Windows.Forms.Button btCadastro;
        private System.Windows.Forms.Button btExcluirCarro;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}