﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar_0._0._5
{
    public partial class Cadastro_Acessorio : Form
    {
        public Cadastro_Acessorio()
        {
            InitializeComponent();
        }

        private void Cadastro_Acessorio_Load(object sender, EventArgs e)
        {
            //coloca todos os radios bottons com a opção "NÃO" como selecionados
            rdbtBluetoothNao.Checked = true;
            rdbtGpsNao.Checked = true;
            rdbtSomBTNao.Checked = true;
            rdbtSomNao.Checked = true;
            rdbtVidroEletricoNao.Checked = true;

            //faz a sita de carros não ser preenchivel (so se pode selecionar)
            cbCodCar.DropDownStyle = ComboBoxStyle.DropDownList;

            //OS DADOS QUE SÃO PRECISOS
            string[] dados = new string[] { "COD_CAR", "NOME_CAR", "PLACA" };

            //NOME DA TABELA
            string tabela = "CARRO";

            //CAMPOS QUE PRECISAM SER PEDIDOS PARA A TABELA
            string campo = "COD_CAR, NOME_CAR, PLACA";

            //INSTANCIANDO A CLASSE QUE PEGA OS DADOS NO BANCO
            SelectBD sbd = new SelectBD();

            //RECEBE OS DADOS DA METODO DA CLASSE SelctBD
            string texto = sbd.selectBD(campo, tabela, dados, "    "); //espasamento e o espaso entre um dado e o outro de forma fisica

            //TRATANDO OS DADOS ENTREGUES
            string[] informacoes = texto.Split(';');//SERA SEPARADO EM VETOR TODA VEZ QUE UM ';' APARECER

            //LOOP PARA ADICIONAR OS DADOS TRATADOS NO VETOR "informacao"
            for (int i = 0; i < informacoes.Length; i++)
                cbCodCar.Items.Add(informacoes[i]);
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            //são constante para a ter 100% de certeza de que não seram auteradas no tempo de execução
            const string TABELA = "ACESSORIO";
            const string CAMPOS = "COD_CAR_FK, SOM, SOM_BT, BLUETOOTH, VIDRO_ELETRICO, GPS";

            //varives que iram registar os acessorios que o cliente colocou ou não no carro
            string bluetooth = "";
            string gps = "";
            string sombt = "";
            string som = "";
            string vidroEletrico = "";


            //caso o cliente tenha selecionado o radio button com a opção "SIM" ele salva o valo "S"
            //se não selecionou ele salva o valor "N"
            bluetooth = rdbtBluetoothSim.Checked == true ? "S" : "N";

            gps = rdbtGpsSim.Checked == true ? "S" : "N";

            sombt = rdbtSomBTSim.Checked == true ? "S" : "N";

            som = rdbtSomSim.Checked == true ? "S" : "N";

            vidroEletrico = rdbtVidroEletricoSim.Checked == true ? "S" : "N";

            //instanciando a classe responsavel por inserir os dados na tabela "ACESSORIO"
            InsertBD bd = new InsertBD();

            //pegando os valores a serem cadastrados
            string dados = mtxtCodCar.Text + "','" + som + "','" + sombt + "','" + bluetooth + "','" + vidroEletrico + "','" + gps;

            DialogResult r;

            do {
                //inserindo os dados e retorna o resultado (se o cadastro foi realizado ou não)
                string resposta = bd.insertBD(TABELA, CAMPOS, dados);

                //se os dados forem cadastrados
                if (resposta == "Cadastrado com sucesso") 
                    r = MessageBox.Show(resposta, "ATENÇÃO");//informa sobre o cadastro

                //caso não seja cadastrado
                else
                    r = MessageBox.Show(resposta, "ATENÇÃO", MessageBoxButtons.RetryCancel);//mostra o erro

            } while (r == DialogResult.Retry);//o Loop continua enquanto o cliente precionar o botão que manda repetir o processo

        }

        private void cbCodCar_SelectedIndexChanged(object sender, EventArgs e)
        {
            //pega o codigo do carro separado
            string[] informacoes = cbCodCar.Text.Split(' ');

            //insere o codico do carro no mtxtCodCar
            mtxtCodCar.Text = informacoes[0];
        }
    }
}
