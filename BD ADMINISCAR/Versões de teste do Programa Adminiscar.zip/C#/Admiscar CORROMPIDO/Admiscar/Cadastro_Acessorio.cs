﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar
{
    public partial class Cadastro_Acessorio : Form
    {
        public Cadastro_Acessorio()
        {
            InitializeComponent();
        }

        
        private void Cadastro_Acessorio_Load(object sender, EventArgs e)
        {

            //coloca todos os radios bottons com a opção "NÃO" como selecionados
            rdbtBluetoothNao.Checked = true;
            rdbtGpsNao.Checked = true;
            rdbtSomBTNao.Checked = true;
            rdbtSomNao.Checked = true;
            rdbtVidroEletricoNao.Checked = true;
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {

            //são constante para a ter 100% de certeza de que não seram auteradas no tempo de execução
            const string TABELA = "ACESSORIO";
            const string CAMPOS = "COD_CAR_FK, SOM, SOM_BT, BLUETOOTH, VIDRO_ELETRICO, GPS";

            //varives que iram registar os acessorios que o cliente colocou ou não no carro
            string bluetooth = "";
            string gps = "";
            string sombt = "";
            string som = "";
            string vidroEletrico = "";


            //caso o cliente tenha selecionado o radio button com a opção "SIM" ele salva o valo "S"
            //se não selecionou ele salva o valor "N"
            bluetooth = rdbtBluetoothSim.Checked == true ? "S" : "N";

            gps = rdbtGpsSim.Checked == true ? "S" : "N";

            sombt =  rdbtSomBTSim.Checked == true ? "S" : "N";

            som = rdbtSomSim.Checked == true ? "S" : "N";

            vidroEletrico = rdbtVidroEletricoSim.Checked == true ? "S" : "N";

            //instanciando a classe responsavel por inserir os dados na tabela "ACESSORIO"
            InsertBD bd = new InsertBD();

            //pegando os valores a serem cadastrados
            string dados = mtxtCodCar.Text + "','" + som + "','" + sombt + "','" + bluetooth + "','" + vidroEletrico + "','" + gps;

            //inserindo os dados
            bd.insertBD(TABELA, CAMPOS, dados);

            //informando ao usuario que os dados forem cadastrados
            MessageBox.Show("Cadastro realizado com sucesso!");
                
        }

    }
}
