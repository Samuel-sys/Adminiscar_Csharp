﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar
{
    public partial class PainelPrincipal : Form
    {
        public PainelPrincipal()
        {
            InitializeComponent();
        }

        private void CadastraBD_Load(object sender, EventArgs e)
        {
            //se inicia com o rdbNão ativado
            rdbNao.Checked = true;
        }

        private void rdbNao_CheckedChanged(object sender, EventArgs e)
        {
            //tem a função de mostrar ou não a area de preenchimento do Usuario e Senha do banco de dados
            Esconde(rdbNao.Checked);
        }
        public void Esconde(Boolean a)
        {
            //se o rdbNão estiver selecionado a area de preenchimento do usuario e senha aparecem se não ficam invisives ao usuario
            txtUsuario.Visible = a ? true : false;
            lblUsuario.Visible = a ? true : false;
            txtSenha.Visible =   a ? true : false;
            lblSenha.Visible =   a ? true : false;
        }
    }
}
