﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admiscar
{
    public partial class PainelCadastro : Form
    {
        public PainelCadastro()
        {
            InitializeComponent();
        }

        private void btCadastro_Click(object sender, EventArgs e)
        {
            Cadastro_Car cr = new Cadastro_Car();
            cr.Show();
        }

        private void btConsulta_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Em manutemção");
        }

        private void btAcessorio_Click(object sender, EventArgs e)
        {
            Cadastro_Acessorio ca = new Cadastro_Acessorio();
            ca.Show();
        }
    }
}