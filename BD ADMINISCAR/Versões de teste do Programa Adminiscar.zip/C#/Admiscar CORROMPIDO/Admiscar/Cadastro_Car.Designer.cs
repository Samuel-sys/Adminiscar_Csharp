﻿namespace Admiscar
{
    partial class Cadastro_Car
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbModelo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.cbCategoria = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbCombustivel = new System.Windows.Forms.ComboBox();
            this.btCadastro = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.mtxtRenavam = new System.Windows.Forms.MaskedTextBox();
            this.mtxtNomeCar = new System.Windows.Forms.MaskedTextBox();
            this.mtxtPlaca = new System.Windows.Forms.MaskedTextBox();
            this.mtxtCor = new System.Windows.Forms.MaskedTextBox();
            this.txtIPVA = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbModelo
            // 
            this.cbModelo.FormattingEnabled = true;
            this.cbModelo.Items.AddRange(new object[] {
            "SEDAN",
            "HATCH",
            "SUV"});
            this.cbModelo.Location = new System.Drawing.Point(156, 178);
            this.cbModelo.Name = "cbModelo";
            this.cbModelo.Size = new System.Drawing.Size(148, 24);
            this.cbModelo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Modelo do Carro:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(107, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Placa";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(82, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Renavam";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Categoria do Carro";
            // 
            // cbCategoria
            // 
            this.cbCategoria.FormattingEnabled = true;
            this.cbCategoria.Items.AddRange(new object[] {
            "ENTRADA",
            "INTERMEDIARIO",
            "ESPORTE",
            "VAN",
            "ESPECIAL"});
            this.cbCategoria.Location = new System.Drawing.Point(156, 208);
            this.cbCategoria.Name = "cbCategoria";
            this.cbCategoria.Size = new System.Drawing.Size(148, 24);
            this.cbCategoria.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(120, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Cor";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(66, 241);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Combustivel";
            // 
            // cbCombustivel
            // 
            this.cbCombustivel.FormattingEnabled = true;
            this.cbCombustivel.Items.AddRange(new object[] {
            "GASOLINA",
            "ALCOOL",
            "FLEX",
            "ELETRICO"});
            this.cbCombustivel.Location = new System.Drawing.Point(156, 238);
            this.cbCombustivel.Name = "cbCombustivel";
            this.cbCombustivel.Size = new System.Drawing.Size(148, 24);
            this.cbCombustivel.TabIndex = 11;
            // 
            // btCadastro
            // 
            this.btCadastro.Location = new System.Drawing.Point(72, 306);
            this.btCadastro.Name = "btCadastro";
            this.btCadastro.Size = new System.Drawing.Size(216, 83);
            this.btCadastro.TabIndex = 13;
            this.btCadastro.Text = "Cadastrar";
            this.btCadastro.UseVisualStyleBackColor = true;
            this.btCadastro.Click += new System.EventHandler(this.btCadastro_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 69);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Nome do carro";
            // 
            // mtxtRenavam
            // 
            this.mtxtRenavam.Location = new System.Drawing.Point(156, 38);
            this.mtxtRenavam.Name = "mtxtRenavam";
            this.mtxtRenavam.Size = new System.Drawing.Size(148, 22);
            this.mtxtRenavam.TabIndex = 16;
            // 
            // mtxtNomeCar
            // 
            this.mtxtNomeCar.Location = new System.Drawing.Point(156, 66);
            this.mtxtNomeCar.Name = "mtxtNomeCar";
            this.mtxtNomeCar.Size = new System.Drawing.Size(148, 22);
            this.mtxtNomeCar.TabIndex = 17;
            // 
            // mtxtPlaca
            // 
            this.mtxtPlaca.Location = new System.Drawing.Point(156, 94);
            this.mtxtPlaca.Name = "mtxtPlaca";
            this.mtxtPlaca.Size = new System.Drawing.Size(148, 22);
            this.mtxtPlaca.TabIndex = 18;
            // 
            // mtxtCor
            // 
            this.mtxtCor.Location = new System.Drawing.Point(156, 122);
            this.mtxtCor.Name = "mtxtCor";
            this.mtxtCor.Size = new System.Drawing.Size(148, 22);
            this.mtxtCor.TabIndex = 19;
            // 
            // txtIPVA
            // 
            this.txtIPVA.Location = new System.Drawing.Point(156, 150);
            this.txtIPVA.Name = "txtIPVA";
            this.txtIPVA.Size = new System.Drawing.Size(148, 22);
            this.txtIPVA.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(146, 17);
            this.label8.TabIndex = 21;
            this.label8.Text = "Comprovante de IPVA";
            // 
            // Cadastro_Car
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(338, 421);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtIPVA);
            this.Controls.Add(this.mtxtCor);
            this.Controls.Add(this.mtxtPlaca);
            this.Controls.Add(this.mtxtNomeCar);
            this.Controls.Add(this.mtxtRenavam);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btCadastro);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbCombustivel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbCategoria);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbModelo);
            this.Name = "Cadastro_Car";
            this.Text = "Cadastro";
            this.Load += new System.EventHandler(this.Cadastro_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbModelo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbCategoria;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbCombustivel;
        private System.Windows.Forms.Button btCadastro;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox mtxtRenavam;
        private System.Windows.Forms.MaskedTextBox mtxtNomeCar;
        private System.Windows.Forms.MaskedTextBox mtxtPlaca;
        private System.Windows.Forms.MaskedTextBox mtxtCor;
        private System.Windows.Forms.TextBox txtIPVA;
        private System.Windows.Forms.Label label8;
    }
}