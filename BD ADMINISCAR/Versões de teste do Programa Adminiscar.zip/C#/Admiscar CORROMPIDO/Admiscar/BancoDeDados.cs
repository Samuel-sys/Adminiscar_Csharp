﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Admiscar
{
    class BancoDeDados
    {
            //criando a pasta onde se cria gravara um arquivo txt com o endereço do banco de dados

            //pote de leitura e escrita
            static StreamReader sr;
            static StreamWriter sw;

        private void PastaDataBase()
        {
            DirectoryInfo di = new DirectoryInfo(@"Data");
            di.CreateSubdirectory(@"DataBase");
        }

        public string BD()//(#BD)
        {
            PastaDataBase();

            //variavel que atribuindo endereço do banco de dados
            string local = "";

            while (local == "")
            {
                if (!File.Exists(@"Data\Database\bd.txt"))
                {
                    using (sw = File.CreateText(@"Data\Database\bd.txt"))
                    {
                        //sistema da maquina do editor desse programa (endereço padrão)
                        sw.Write(@"Data Source = DESKTOP-N6E750J\SQLEXPRESS; Initial Catalog = ADMINISCAR; Integrated Security = True");
                    }
                }
                else
                {
                    using (sr = File.OpenText(@"Data\Database\bd.txt"))
                    {
                        //caso já tenha cadastro no arquivo txt ele ira ler o endereço
                        local = sr.ReadLine();
                    }
                }
            }

            //retorna o endereço do banco de dados
            return local;
        }


        public void cadastraBD(string instancia, string DataBase, string usuario, string senha)
        {
            //caso a pasta não exista ela sera criada
            PastaDataBase();

            //caso o arquivo não exista sera criado um com um endereço padrão
            BD();

            string banco = @"Data Source = " + instancia + "; Initial Catalog = " + DataBase +
                /*Caso o não se de senha ou usuarioa vai se entender que e um caso de Integrated Securyt caso o contrario sera cadastrado*/
                usuario == "" && senha == "" ? "Integrated Security = True" : "USER ID = " + usuario + " PASSWORD = " + senha;

            using (sr = File.OpenText(@"Data\Database\bd.txt"))
            {
                //escrevendo as informações do banco de dados no ficheiro
                sw.Write(banco);
            }
        }
    }
}
