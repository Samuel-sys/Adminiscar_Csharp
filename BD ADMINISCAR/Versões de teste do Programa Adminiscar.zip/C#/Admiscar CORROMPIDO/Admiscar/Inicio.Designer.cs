﻿namespace Admiscar
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastroBD = new System.Windows.Forms.Button();
            this.CadastroCarAcss = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btCadastroBD
            // 
            this.btCadastroBD.Location = new System.Drawing.Point(12, 12);
            this.btCadastroBD.Name = "btCadastroBD";
            this.btCadastroBD.Size = new System.Drawing.Size(223, 397);
            this.btCadastroBD.TabIndex = 0;
            this.btCadastroBD.Text = "Cadastro do Banco de Dados";
            this.btCadastroBD.UseVisualStyleBackColor = true;
            this.btCadastroBD.Click += new System.EventHandler(this.btCadastroBD_Click);
            // 
            // CadastroCarAcss
            // 
            this.CadastroCarAcss.Location = new System.Drawing.Point(241, 12);
            this.CadastroCarAcss.Name = "CadastroCarAcss";
            this.CadastroCarAcss.Size = new System.Drawing.Size(223, 397);
            this.CadastroCarAcss.TabIndex = 1;
            this.CadastroCarAcss.Text = "Cadastro de Carros e Acessorios";
            this.CadastroCarAcss.UseVisualStyleBackColor = true;
            this.CadastroCarAcss.Click += new System.EventHandler(this.CadastroCarAcss_Click);
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 421);
            this.Controls.Add(this.CadastroCarAcss);
            this.Controls.Add(this.btCadastroBD);
            this.Name = "Inicio";
            this.Text = "Inicio";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCadastroBD;
        private System.Windows.Forms.Button CadastroCarAcss;
    }
}