﻿namespace Admiscar
{
    partial class PainelCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastro = new System.Windows.Forms.Button();
            this.btConsultaCarro = new System.Windows.Forms.Button();
            this.btAcessorio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btCadastro
            // 
            this.btCadastro.Location = new System.Drawing.Point(12, 12);
            this.btCadastro.Name = "btCadastro";
            this.btCadastro.Size = new System.Drawing.Size(247, 252);
            this.btCadastro.TabIndex = 0;
            this.btCadastro.Text = "Cadastrar carro";
            this.btCadastro.UseVisualStyleBackColor = true;
            this.btCadastro.Click += new System.EventHandler(this.btCadastro_Click);
            // 
            // btConsultaCarro
            // 
            this.btConsultaCarro.Location = new System.Drawing.Point(265, 12);
            this.btConsultaCarro.Name = "btConsultaCarro";
            this.btConsultaCarro.Size = new System.Drawing.Size(237, 513);
            this.btConsultaCarro.TabIndex = 1;
            this.btConsultaCarro.Text = "Cousultar carro";
            this.btConsultaCarro.UseVisualStyleBackColor = true;
            this.btConsultaCarro.Click += new System.EventHandler(this.btConsulta_Click);
            // 
            // btAcessorio
            // 
            this.btAcessorio.Location = new System.Drawing.Point(12, 273);
            this.btAcessorio.Name = "btAcessorio";
            this.btAcessorio.Size = new System.Drawing.Size(247, 252);
            this.btAcessorio.TabIndex = 2;
            this.btAcessorio.Text = "Cadastrar de Acessorios de Carro";
            this.btAcessorio.UseVisualStyleBackColor = true;
            this.btAcessorio.Click += new System.EventHandler(this.btAcessorio_Click);
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 538);
            this.Controls.Add(this.btAcessorio);
            this.Controls.Add(this.btConsultaCarro);
            this.Controls.Add(this.btCadastro);
            this.Name = "Principal";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCadastro;
        private System.Windows.Forms.Button btConsultaCarro;
        private System.Windows.Forms.Button btAcessorio;
    }
}

