﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace delete
{
    class Program
    {

        //conexão com o banco de dados (foi colocado fora para ser usado por mais de um metodo
        static SqlConnection conect = new SqlConnection(@"Data Source = DESKTOP-N6E750J\SQLEXPRESS; Initial Catalog = ADMINISCAR; Integrated Security = True");


        static void Main(string[] args)
        {
            //pedindo o codigo da Primary key do banco
            Console.Write("Codigo: ");
            int cod = int.Parse(Console.ReadLine());


            //o nome da tabela onde esta a linha que eseja apagar
            string tabela = "CARRO";

            //nome da coluna para ser usado como parametro
            string coluna = "COD_CAR";

            DeleteWhere(tabela, coluna, cod);

            Console.WriteLine("quer deletar tudo ? S/N");
            switch(Console.ReadLine().ToUpper())
            {
                case "S":
                DeleteFull(tabela);
                    break;
                case "N":
                    Console.WriteLine("Não deletamos então");
                    break;
                default:
                    Console.WriteLine("Codigo não reconhecido");
                    break;

            }

        }

        static void DeleteWhere(string tabela, string coluna, int cod)
        {
            SqlCommand comando = new SqlCommand("DELETE FROM " + tabela + " WHERE " + coluna + " = " + cod, conect);

            conect.Open();

            comando.ExecuteNonQuery();

            conect.Close();
        }

        static void DeleteFull(string tabela)
        {
            SqlCommand comando = new SqlCommand("DELETE FROM " + tabela , conect);

            conect.Open();

            comando.ExecuteNonQuery();

            conect.Close();
        }

    }
}
