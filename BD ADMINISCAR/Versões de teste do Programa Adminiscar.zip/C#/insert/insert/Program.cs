﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace insert
{
    class Program
    {
        static SqlConnection conect = new SqlConnection(@"Data Source = DESKTOP-N6E750J\SQLEXPRESS; Initial Catalog = ADMINISCAR; Integrated Security = True");
        static void Main(string[] args)
        {
            Console.WriteLine("Informe dessa fora \n\ncoluna1, coluna2, coluna3 .....");

            Console.Write("Informe as colunas: ");
            string a = Console.ReadLine();//pedindo os nomes das colunas que seram preenchidas

            //separa os nomes das colunas em um vetor
            string[] colunas = a.Split(',');

            //fazemdo o comando no C# com conexão com o banco de dados
            SqlCommand comando = new SqlCommand(comandoSQL(colunas) + InsereValor(colunas), conect);

            //abrindo o banco
            conect.Open();
            for(int i = 0; i < 30; i++)
            //efetuando o comando
            comando.ExecuteNonQuery();

            //fechando o banco
            conect.Close();

            //pausa a tela
            Console.ReadKey();
        }

        //sera o metodo responsavel por criar uma variavel do tipo string com todos os valores que seram inseridos no banco
        static string InsereValor(string[] campos)
        {
            string value = "(' ";

            for (int i = 0; i < campos.Length; i++)
            {
                Console.Write("{0} : ", campos[i]);
                value += Console.ReadLine();
                if (i != campos.Length - 1)
                    value += "' , '";
                else
                    value += " ')";
            }

            //value = ('variavel1', 'variavel2', 'variavel3') ira sair algo mais ou menos assim
            return value;
        }

        //responsavel por montar o resto do codigo de SQL para ser execultado no C#
        static string comandoSQL(string[] colunas)
        {
            //nome da tabela
            string tabela = "CARRO";

            //inicio do codigo
            string comand = "INSERT INTO " + tabela + " (";

            for (int i = 0; i < colunas.Length; i++)
            {
                if (i == 0)
                    comand += colunas[i];

                else
                    comand += ", " + colunas[i];
            }

            //caso seja apenas uma coluna a ser inserida o comando em SQL muda apenas essa parte
            if (colunas.Length == 1)//caso #1
                comand += ") VALUE";

            else//caso #2
                comand += ") VALUES ";


            // comand = "INSERT INTO (CAMPO1) VALUE (" o resultado e mais ou menos assim no caso #1
            // comand = "INSERT INTO (CAMPO1, CAMPO2, CAMPO3) VALUES (" o resultado e mais ou menos assim no caso #2
            return comand;

        }
        //===============================================
        /*** esta desativado por tempo indeterminado ***/
        //===============================================

        //area de manipulação de dado para se caso quiser pegar os nomes da colunas juntas ou separadas e assim tratarem elas para um modo que o programa aceite

        /*static string[] ColunasSeparadas()
        {
            int c = 0;

            while (c <= 0)
            {

                Console.Write("quantas colunas: ");
                while (!int.TryParse(Console.ReadLine(), out c) == true)
                    Console.Write("Valor invalino: ");

                if (c <= 0)
                    Console.WriteLine("Valor invalino ");
            }

            string[] colunas = new string[c];

            for (int i = 0; i < c; i++)
            {
                Console.Write("Nome da {0}° coluna: ", i + 1);
                colunas[i] = Console.ReadLine();
            }

            return colunas;
        }

        static string[] ColunasJuntas()
        {
            Console.WriteLine("Informe dessa fora \n\ncoluna1, coluna2, coluna3 .....");

            Console.Write("Informe as colunas: ");
            string a = Console.ReadLine();

            string[] colunas = a.Split(',');

            return colunas;
        }
        */

    }
}
