﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace select
{
    class Program
    {
        static SqlConnection conect = new SqlConnection(@"Data Source = DESKTOP-N6E750J\SQLEXPRESS; Initial Catalog = ADMINISCAR; Integrated Security = True");
        static void Main(string[] args)
        {
            Console.Write("qual tabela?");
            string tabela = Console.ReadLine();

            string texto = "";

            try
            {
                SqlCommand comando = new SqlCommand("SELECT * FROM " + tabela, conect);
                conect.Open();
                SqlDataReader dr = comando.ExecuteReader();

                while (dr.Read())
                {
                    for (int i = 0; i < 10; i++)
                    {
                        //caso não seja o ultimo campo
                        if (i != 9)
                            texto += dr[i].ToString() + ", ";

                        //caso seja o ultimo campo
                        else
                        {
                            try
                            {
                            texto += dr[i] + ";";//o final tem que ser um ";" para poder ser separado pelo cliente no processo de tratamento
                            }
                            catch (Exception A)
                            {
                                Console.WriteLine(A);
                            }

                        }
                    }
                    texto += "\n";
                }

                Console.WriteLine(texto);

            }
            catch (Exception a)
            {
                Console.WriteLine(a.Message);
            }
            finally
            {
                conect.Close();
            }

                Console.ReadKey();
        }
    }
}
