﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace UPDATE
{
    class Program
    {
        static SqlConnection conect = new SqlConnection(@"Data Source = DESKTOP-N6E750J\SQLEXPRESS; Initial Catalog = ADMINISCAR; Integrated Security = True");
        static void Main(string[] args)
        {
            //pergunta o codigo que sera usado para alterar o sistema
            Console.Write("qual o codigo ?");
            string cod_referencia = Console.ReadLine();
            
            //o dado que sera usado para sobrescrever o campo escolhido
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            //nome da tabela
            string tabela = "CARRO";

            //nome do campo que sera alterado
            string campo_alterado = "NOME_CAR";

            //campo que sera usado como referencia
            string campo_compara = "COD_CAR";

            //UPDATE tabela SET coluna = 'novo_dado' WHERE coluna_refetencia  = dado_referencia             algo mais ou menos assim
            string comandoSQL = "UPDATE " + tabela + " SET NOME_CAR = '" + nome + "' WHERE " + campo_compara + " = " + cod_referencia;

            //ponte que ira execultar o comando no banco SQL server
            SqlCommand comando = new SqlCommand(comandoSQL, conect);


            conect.Open();
            comando.ExecuteNonQuery();
            conect.Close();
        }
    }
}
